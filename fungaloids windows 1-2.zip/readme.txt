This project has been converted to Lazarus and Free PASCAL. 2025.

The path's have been fixed so it should run anywhere.
The playing area has been upped so it can be played on 1080p.

See the vid.

exe file is in : 

lib\x86_64-win64

